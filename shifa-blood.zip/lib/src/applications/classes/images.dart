class Images {
  static String defaultImage = "assets/images/default.png";
  static String defaultUserImage = "assets/images/default.png";

  static String signImage = "assets/images/signup.jpg";
  static String signupImage = "assets/images/signin.jpg";
  static String bloodImage = "assets/friends/blood.jpg";
  static String productImage = "assets/friends/product.jpg";
  static String healthImage = "assets/friends/helth2.jpg";
  static String educationImage = "assets/friends/education2.jpg";
  static String moreImage = "assets/friends/more.jpg";
  static String matrimonialImage = "assets/images/matrimonial.jpg";
  static String aboutusImage = "assets/images/aboutus.png";
  static String businessImage = "assets/images/business.jpg";
  static String pakundiaImage = "assets/images/pakundia.jpg";
  static String newsImage = "assets/images/news.jpg";
  static String hospitalImage = "https://jim.pakundia.me/images/common/hospital.jpg";
  static String doctorImage = "https://jim.pakundia.me/images/common/doctor.jpg";
  static String educationInstitution = "assets/images/education.jpg";
  static String tutorImage = "assets/images/tutor.jpg";

}