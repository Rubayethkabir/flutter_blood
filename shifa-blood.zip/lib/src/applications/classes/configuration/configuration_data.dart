import 'package:TenTwelveBlood/src/applications/classes/configuration/configuration_class.dart';
import 'package:flutter/cupertino.dart';

class ConfigurationData {
 final ConfigurationClass configuration;
  ConfigurationData({@required this.configuration});
}