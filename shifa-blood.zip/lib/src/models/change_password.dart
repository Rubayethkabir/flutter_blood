class ChangePassword {
  String id;
  String currentPassword;
  String newPassword;
  String newRetypePassword;
  
  ChangePassword();

}
