package com.example.TenTwelveBlood

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
